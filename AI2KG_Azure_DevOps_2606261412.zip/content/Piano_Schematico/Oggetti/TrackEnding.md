---
KP: false
Direction: true
---
Un TrackEnding è una tipologia di [Entity](Piano_Schematico/Oggetti/Entity.md) Un TrackEnding possiede informazione di [Direzionalità](Piano_Schematico/Direzionalità.md) ma non possiede informazione riguardante [Punto_Chilometrica](Piano_Schematico/Punto_Chilometrica.md) ricadendo nella categoria degli [Oggetti Virtuali](Oggetti%20Virtuali). Un TrackEnding è un indicatore logico, fornisce informazioni sul proseguimento della linea dell'impianto, nei casi in cui il [TrackPlanModel](Piano_Schematico/Oggetti/TrackPlanModel.md) non copra l'intera linea. TrackEnding fornisce le seguenti informazioni:
- **Stazione Finale**: La stazione finale proseguendo la linea ([TrackSegment](Piano_Schematico/Oggetti/TrackSegment.md)) nella direzione specificata.
- **Fermata Successiva**: La prossima fermata proseguendo la linea ([TrackSegment](Piano_Schematico/Oggetti/TrackSegment.md)) nella direzione specificata.



