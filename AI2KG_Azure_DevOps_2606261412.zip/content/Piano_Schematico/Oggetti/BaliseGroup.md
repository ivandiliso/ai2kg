  
BALISE GROUP  (direzionato)

questo oeggetto deve tener conto del senso di marcia legale del treno un binario legare è quello che deve sempore percorrere secondo il senso di marcia per questoha un attributo del traffic dierction che indica se il senso di marcia è diverso dalla direzione del balise 

attributo di boundary ci dice se la balise è una balise di confine 

ci dice se è uno di tre tipi di boundary 

- Entry: entrata RBC (deve essere connessa in una RBC Area
    
- Exit: uscita area RBC (deve essree connessa in una RBC AREA) 
    
- HandOver (nel file RBC)cambio area rbc competenza, puo essre in due, ma deve essree in una, ma deve