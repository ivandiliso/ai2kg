Un **Profilo** rappresenta una specifica caratterizzazione di una [Entity](Piano_Schematico/Oggetti/Entity.md) o di una [Area](Piano_Schematico/Oggetti/Area.md). Più [Area](Piano_Schematico/Oggetti/Area.md) possono condividere lo stesso Profilo, pur essendo [Area](Piano_Schematico/Oggetti/Area.md) di tipologie diverse. 

Vengono riconosciute due tipologie principali di Profilo:

- [GradientProfile]]
- [StaticSpeedProfile](StaticSpeedProfile)

Questi sono rispettivamente legati alle sotto tipologie di Aree:

- [GradientArea](GradientArea)
- [StaticSpeedArea](StaticSpeedArea)
