**KPP Point  (direzioneat)

è un punto con una chilimetrica

KP JUmp indica la chilimetrica a sinistra e destra 

un KP Jumpo di solito poggia su un KP Point, sul CIrcuitjoint 

Conviene separarlo da una Centity ma come una caratterizzazione che va a specificare una differenza di chilometriche a sinistra e destra**