---
KP: true
Direction: true
---
Uno BufferStop è una tipologia di [Entity](Piano_Schematico/Oggetti/Entity.md).  Presenta informazione di [Direzionalità](Piano_Schematico/Direzionalità.md) e di [[Punto Chilometrica (KP)]([Punto%20Chilometrica%20(KP)), ricadendo nella categoria degli [Oggetti Reali](Oggetti%20Reali).  Un BufferStop rientra nella categoria degli oggetti.

