Un Terminale è una tipologia di [Entity](Piano_Schematico/Oggetti/Entity.md) che rappresenta una terminazione di una linea. Oggetti di tipologia terminale devono presentare informazione di [Direzionalità](Piano_Schematico/Direzionalità.md). Gli oggetti associati a questa categoria sono:
- [TrackEnding](Piano_Schematico/Oggetti/TrackEnding.md)
- [BufferStop](Piano_Schematico/Oggetti/BufferStop.md)
