
Una **Entity** rappresenta qualsiasi oggetto presente nel piano schematico, sia esso [Oggetti Virtuali](Oggetti%20Virtuali), [Oggetti Reali](Oggetti%20Reali) o [Oggetti Aggregati](Oggetti%20Aggregati).

Il concetto di Entity è una **superclasse comune** che viene poi specializzata da oggetti più specifici del dominio, i quali ne ereditano e raffinano le caratteristiche tramite attributi aggiuntivi.

Ogni Entity presenta informazioni riguardo la sua presenza o meno sul piano schematico reale, questo, permette di differenziare l'oggetto tra [Oggetti Reali](Oggetti%20Reali) e [Oggetti Virtuali](Oggetti%20Virtuali). 

>[!warning] KP e Entity
> Questa informazione non è sempre presente, ma può essere recuperata analizzando il valore di [Punto Chilometrica](../Punto_Chilometrica.md), questo, se avvalorato a 0 o non presente, indica che l'Entità è di tipo [Oggetti Virtuali](Oggetti%20Virtuali), non presenta quindi una posizione nel piano schematico reale. 

Ogni Entity:
- deve essere collegata a un [TrackSegment](TrackSegment.md)
- rappresenta un oggetto posizionato lungo un elemento del tracciato

Le Entity possono o meno presentare informazione sulla [Direzionalità](../Direzionalità.md) indicando la direzione rispetto al [TrackSegment](TrackSegment.md) di riferimento.



