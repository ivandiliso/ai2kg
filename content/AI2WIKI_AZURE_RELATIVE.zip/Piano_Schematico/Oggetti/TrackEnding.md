---
KP: false
Direction: true
---
Un TrackEnding è una tipologia di [Entity](Entity.md) Un TrackEnding possiede informazione di [Direzionalità](../Direzionalità.md) ma non possiede informazione riguardante [Punto Chilometrica](../Punto_Chilometrica.md) ricadendo nella categoria degli [Oggetti Virtuali](Oggetti%20Virtuali). Un TrackEnding è un indicatore logico, fornisce informazioni sul proseguimento della linea dell'impianto, nei casi in cui il [TrackPlanModel](TrackPlanModel.md) non copra l'intera linea. TrackEnding fornisce le seguenti informazioni:
- **Stazione Finale**: La stazione finale proseguendo la linea ([TrackSegment](TrackSegment.md)) nella direzione specificata.
- **Fermata Successiva**: La prossima fermata proseguendo la linea ([TrackSegment](TrackSegment.md)) nella direzione specificata.



