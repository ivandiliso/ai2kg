---
KP: true
Direction: true
---
Uno BufferStop è una tipologia di [Entity](Entity.md).  Presenta informazione di [Direzionalità](../Direzionalità.md) e di [[Punto Chilometrica (KP)](KP)))), ricadendo nella categoria degli [Oggetti Reali](Oggetti%20Reali).  Un BufferStop rientra nella categoria degli oggetti.

